package foop.serialization.test;

public class MessageTest {

}
